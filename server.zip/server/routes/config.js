module.exports = {
  jwtSecret: "jsonwebtoken11",
  expiresIn: 24 * 60 * 60
};
